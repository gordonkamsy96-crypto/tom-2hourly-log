package com.gppol.tomsupervisorlog

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime

private val GridColor = Color(0xFF6B7280)
private val FrameColor = Color(0xFF111111)
private val InkBlue = Color(0xFF0B2E7A)
private val LabelBg = Color(0xFFF1F4F8)
private val BlankBg = Color(0xFFE5E8EC)
private val SectionBg = Color(0xFF2F5D50)
private val RowH = 40.dp
private val TallRowH = 72.dp
private val MinSheetWidth = 760.dp

/** The whole log sheet as a scrollable form. [locked] = submitted: only verification fields stay editable. */
@Composable
fun SheetForm(report: Report, locked: Boolean, modifier: Modifier = Modifier) {
    val vScroll = rememberScrollState()
    BoxWithConstraints(modifier.fillMaxSize()) {
        val narrow = maxWidth < MinSheetWidth
        val hScroll = rememberScrollState()
        Box(Modifier.fillMaxSize().verticalScroll(vScroll), contentAlignment = Alignment.TopCenter) {
            Box(if (narrow) Modifier.horizontalScroll(hScroll) else Modifier) {
                Column(
                    (if (narrow) Modifier.width(MinSheetWidth) else Modifier.fillMaxWidth().widthIn(max = 1200.dp))
                        .padding(horizontal = if (narrow) 4.dp else 12.dp, vertical = 10.dp)
                ) {
                    Column(Modifier.fillMaxWidth().border(2.5.dp, FrameColor)) {
                    SheetHeader()
                    FORM_BLOCKS.forEach { block ->
                        when (block) {
                            is Block.Section -> SectionHeader(block.title)
                            is Block.Grid -> GridRows(block.rows, FormMeta.COLUMN_WEIGHTS, report, locked)
                            is Block.GridWithRemarks -> {
                                val w = FormMeta.COLUMN_WEIGHTS
                                Row(Modifier.fillMaxWidth()) {
                                    Column(Modifier.weight(w.take(5).sum())) {
                                        GridRows(block.rows, w.take(5), report, locked)
                                    }
                                    Box(
                                        Modifier
                                            .weight(w.drop(5).sum())
                                            .height(RowH * block.rows.size)
                                            .border(0.5.dp, GridColor)
                                    ) {
                                        NoteBox(block.remarksLabel, report, block.remarksKey, !locked)
                                    }
                                }
                            }
                            is Block.Remarks -> Box(
                                Modifier.fillMaxWidth().height(RowH * block.rows).border(0.5.dp, GridColor)
                            ) {
                                NoteBox(block.label, report, block.key, !locked)
                            }
                        }
                    }
                    }
                    Box(Modifier.height(24.dp))
                }
            }
        }
    }
}

@Composable
private fun SheetHeader() {
    Row(Modifier.fillMaxWidth().height(RowH * 2.4f)) {
        Column(
            Modifier.weight(3.8f).fillMaxHeight().border(0.5.dp, GridColor).padding(horizontal = 8.dp),
            verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            Text("Document No.   ${FormMeta.DOC_NO}", fontSize = 12.sp)
            Text("Revision   ${FormMeta.REVISION}", fontSize = 12.sp)
            Text("Revision Date   ${FormMeta.REVISION_DATE}", fontSize = 12.sp)
            Text("Mill/Site   ${FormMeta.SITE}", fontSize = 12.sp)
        }
        Box(
            Modifier.weight(4f).fillMaxHeight().border(0.5.dp, GridColor).padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(FormMeta.TITLE, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        Box(
            Modifier.weight(3f).fillMaxHeight().background(Color.White).border(0.5.dp, GridColor).padding(6.dp),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(R.drawable.nbpol_logo),
                contentDescription = "New Britain Palm Oil logo",
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

@Composable
private fun SectionHeader(title: String) {
    Box(
        Modifier.fillMaxWidth().height(34.dp).background(SectionBg).border(0.5.dp, GridColor),
        contentAlignment = Alignment.Center
    ) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

@Composable
private fun GridRows(rows: List<FormRow>, weights: List<Float>, report: Report, locked: Boolean) {
    Column(Modifier.fillMaxWidth()) {
        rows.forEach { row ->
            var col = 0
            Row(Modifier.fillMaxWidth().height(if (row.tall) TallRowH else RowH)) {
                row.cells.forEach { cell ->
                    val w = weights.subList(col, col + cell.span).sum()
                    CellBox(cell, col, w, report, locked)
                    col += cell.span
                }
            }
        }
    }
}

@Composable
private fun RowScope.CellBox(cell: Cell, startCol: Int, weight: Float, report: Report, locked: Boolean) {
    val bg = when (cell) {
        is Cell.Label -> LabelBg
        is Cell.Blank -> BlankBg
        is Cell.Input -> Color.White
    }
    Box(
        Modifier.weight(weight).fillMaxHeight().background(bg).border(0.5.dp, GridColor),
        contentAlignment = Alignment.Center
    ) {
        when (cell) {
            is Cell.Blank -> {}
            is Cell.Label -> {
                val centred = labelCentered(cell.text, cell.span, startCol)
                Text(
                    cell.text,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 5.dp),
                    fontSize = 12.sp,
                    lineHeight = 14.sp,
                    fontWeight = if (cell.text.all { it.isDigit() }) FontWeight.Bold else FontWeight.Normal,
                    textAlign = if (centred) TextAlign.Center else TextAlign.Start,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            is Cell.Input -> InputCell(cell, report, locked)
        }
    }
}

@Composable
private fun InputCell(cell: Cell.Input, report: Report, locked: Boolean) {
    val key = cell.key
    val value = report.values[key].orEmpty()
    val editable = !locked || key in FormMeta.VERIFICATION_KEYS
    val set: (String) -> Unit = { report.values[key] = it }
    when (cell.kind) {
        Kind.NUM -> TextCell(value, editable, KeyboardType.Decimal, TextAlign.Center, set)
        Kind.TEXT -> TextCell(value, editable, KeyboardType.Text, TextAlign.Start, set)
        Kind.YESNO -> YesNoCell(value, editable, set)
        Kind.DATE -> PickerCell(
            text = if (value.isBlank()) "Select date" else formatDate(value),
            placeholder = value.isBlank(),
            editable = editable
        ) { ctx ->
            val d = parseDate(value) ?: LocalDate.now()
            DatePickerDialog(ctx, { _, y, m, day -> set(LocalDate.of(y, m + 1, day).toString()) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
        }
        Kind.TIME -> PickerCell(
            text = if (value.isBlank()) "Select time" else value,
            placeholder = value.isBlank(),
            editable = editable
        ) { ctx ->
            val t = parseTime(value) ?: LocalTime.now()
            TimePickerDialog(ctx, { _, h, m -> set(String.format("%02d:%02d", h, m)) }, t.hour, t.minute, true).show()
        }
        Kind.SIGN -> SignatureCell(value, editable, set)
    }
}

@Composable
private fun TextCell(value: String, editable: Boolean, keyboard: KeyboardType, align: TextAlign, onChange: (String) -> Unit) {
    BasicTextField(
        value = value,
        onValueChange = onChange,
        readOnly = !editable,
        singleLine = true,
        textStyle = TextStyle(fontSize = 16.sp, color = InkBlue, textAlign = align, fontWeight = FontWeight.Medium),
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, imeAction = ImeAction.Next),
        cursorBrush = SolidColor(InkBlue),
        modifier = Modifier.fillMaxSize(),
        decorationBox = { inner ->
            Box(
                Modifier.fillMaxSize().padding(horizontal = 5.dp),
                contentAlignment = if (align == TextAlign.Center) Alignment.Center else Alignment.CenterStart
            ) { inner() }
        }
    )
}

@Composable
private fun YesNoCell(value: String, editable: Boolean, onChange: (String) -> Unit) {
    val bg = when (value) {
        "Yes" -> Color(0xFFD6F0DC)
        "No" -> Color(0xFFF9D9D6)
        else -> Color.Transparent
    }
    Box(
        Modifier.fillMaxSize().background(bg).clickable(enabled = editable) {
            onChange(
                when (value) {
                    "" -> "Yes"
                    "Yes" -> "No"
                    else -> ""
                }
            )
        },
        contentAlignment = Alignment.Center
    ) {
        if (value.isEmpty()) Text("Yes / No", fontSize = 11.sp, color = Color(0xFF9AA0A6))
        else Text(value, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = InkBlue)
    }
}

@Composable
private fun PickerCell(text: String, placeholder: Boolean, editable: Boolean, onClick: (android.content.Context) -> Unit) {
    val ctx = LocalContext.current
    Box(
        Modifier.fillMaxSize().clickable(enabled = editable) { onClick(ctx) },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            fontSize = if (placeholder) 12.sp else 15.sp,
            fontWeight = if (placeholder) FontWeight.Normal else FontWeight.Medium,
            color = if (placeholder) Color(0xFF9AA0A6) else InkBlue
        )
    }
}

@Composable
private fun NoteBox(label: String, report: Report, key: String, editable: Boolean) {
    val value = report.values[key].orEmpty()
    Column(Modifier.fillMaxSize().padding(6.dp)) {
        Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        BasicTextField(
            value = value,
            onValueChange = { report.values[key] = it },
            readOnly = !editable,
            textStyle = TextStyle(fontSize = 15.sp, color = InkBlue),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text, imeAction = ImeAction.Default),
            cursorBrush = SolidColor(InkBlue),
            modifier = Modifier.fillMaxSize()
        )
    }
}
