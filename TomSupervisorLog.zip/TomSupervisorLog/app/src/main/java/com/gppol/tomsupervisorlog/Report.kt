package com.gppol.tomsupervisorlog

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import org.json.JSONObject
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.UUID

enum class Status { DRAFT, SUBMITTED }

/** One filled-in log sheet. Values are keyed by the Excel cell coordinate of the original sheet. */
class Report(
    val id: String,
    val createdAt: Long,
    var updatedAt: Long,
    status: Status,
    var submittedAt: Long?,
    val values: SnapshotStateMap<String, String>
) {
    var status by mutableStateOf(status)

    fun v(key: String): String = values[key].orEmpty()

    /** True when nothing except the pre-filled date has been entered. */
    fun isPristine(): Boolean = values.all { (k, v) -> k == "B6" || v.isBlank() }

    fun snapshot() = ReportData(id, status, submittedAt, values.toMap())

    fun missingRequired(): List<String> =
        FormMeta.REQUIRED.filter { (key, _) -> v(key).isBlank() }.map { it.second }

    fun blankReadings(): Int = READING_KEYS.count { v(it).isBlank() }
}

/** Immutable copy handed to background work such as PDF generation. */
class ReportData(val id: String, val status: Status, val submittedAt: Long?, val values: Map<String, String>)

class ReportStore(context: Context) {
    private val dir = File(context.filesDir, "reports").apply { mkdirs() }

    fun create(): Report {
        val now = System.currentTimeMillis()
        val values = mutableStateMapOf<String, String>()
        values["B6"] = LocalDate.now().toString()
        return Report(UUID.randomUUID().toString(), now, now, Status.DRAFT, null, values)
    }

    @Synchronized
    fun save(r: Report) {
        r.updatedAt = System.currentTimeMillis()
        val json = JSONObject().apply {
            put("id", r.id)
            put("status", r.status.name)
            put("createdAt", r.createdAt)
            put("updatedAt", r.updatedAt)
            put("submittedAt", r.submittedAt ?: JSONObject.NULL)
            put("values", JSONObject(r.values.filterValues { it.isNotEmpty() }.toMap()))
        }
        val tmp = File(dir, "${r.id}.json.tmp")
        tmp.writeText(json.toString())
        val target = File(dir, "${r.id}.json")
        if (!tmp.renameTo(target)) {
            target.delete()
            tmp.renameTo(target)
        }
    }

    @Synchronized
    fun loadAll(): List<Report> {
        val files = dir.listFiles { f -> f.name.endsWith(".json") } ?: return emptyList()
        return files.mapNotNull { f ->
            runCatching {
                val o = JSONObject(f.readText())
                val values = mutableStateMapOf<String, String>()
                val vo = o.getJSONObject("values")
                vo.keys().forEach { k -> values[k] = vo.getString(k) }
                Report(
                    id = o.getString("id"),
                    createdAt = o.getLong("createdAt"),
                    updatedAt = o.getLong("updatedAt"),
                    status = Status.valueOf(o.getString("status")),
                    submittedAt = if (o.isNull("submittedAt")) null else o.getLong("submittedAt"),
                    values = values
                )
            }.getOrNull()
        }.sortedWith(compareByDescending<Report> { it.v("B6") }.thenByDescending { it.v("F6") }.thenByDescending { it.updatedAt })
    }

    @Synchronized
    fun delete(id: String) {
        File(dir, "$id.json").delete()
    }
}

// ---------- formatting helpers ----------

private val DATE_OUT = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH)

fun parseDate(s: String): LocalDate? = runCatching { LocalDate.parse(s) }.getOrNull()
fun parseTime(s: String): LocalTime? = runCatching { LocalTime.parse(s) }.getOrNull()
fun formatDate(s: String): String = parseDate(s)?.format(DATE_OUT) ?: s

/** Column-heading style labels are centred (1, 2, OIL, Water...); descriptive labels are left-aligned. */
fun labelCentered(text: String, span: Int, startCol: Int): Boolean =
    text.all { it.isDigit() } || (startCol > 0 && span == 1 && text.length <= 10)
