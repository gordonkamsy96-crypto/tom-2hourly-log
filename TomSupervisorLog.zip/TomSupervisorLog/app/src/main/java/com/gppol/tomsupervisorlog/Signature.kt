package com.gppol.tomsupervisorlog

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.util.Locale

/**
 * Signatures are stored as text: strokes separated by '|', points by ';', and each point "x,y"
 * normalised to a 3:1 (width:height) box so they render identically on screen and in the PDF.
 */
object SignatureCodec {
    const val ASPECT = 3f

    fun encode(strokes: List<List<Offset>>, w: Float, h: Float): String {
        if (w <= 0f || h <= 0f) return ""
        return strokes.filter { it.isNotEmpty() }.joinToString("|") { stroke ->
            stroke.joinToString(";") { p -> String.format(Locale.US, "%.3f,%.3f", p.x / w, p.y / h) }
        }
    }

    fun decode(s: String): List<List<Offset>> {
        if (s.isBlank()) return emptyList()
        return s.split("|").map { stroke ->
            stroke.split(";").mapNotNull { pt ->
                val a = pt.split(",")
                val x = a.getOrNull(0)?.toFloatOrNull()
                val y = a.getOrNull(1)?.toFloatOrNull()
                if (x != null && y != null) Offset(x, y) else null
            }
        }.filter { it.isNotEmpty() }
    }
}

/** Draws normalised strokes centred and scaled to fit the current draw area. */
fun DrawScope.drawSignature(strokes: List<List<Offset>>, color: Color, strokeWidth: Float) {
    val s = minOf(size.width / SignatureCodec.ASPECT, size.height)
    val ox = (size.width - s * SignatureCodec.ASPECT) / 2f
    val oy = (size.height - s) / 2f
    for (st in strokes) {
        if (st.size == 1) {
            drawCircle(color, strokeWidth / 2f, Offset(ox + st[0].x * s * SignatureCodec.ASPECT, oy + st[0].y * s))
        } else {
            val p = Path()
            st.forEachIndexed { i, pt ->
                val x = ox + pt.x * s * SignatureCodec.ASPECT
                val y = oy + pt.y * s
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            drawPath(p, color, style = Stroke(width = strokeWidth, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
    }
}

private val Ink = Color(0xFF0B2E7A)

/** The small box inside the form: shows the signature, tap to (re)sign. */
@Composable
fun SignatureCell(value: String, enabled: Boolean, onChange: (String) -> Unit) {
    var show by remember { mutableStateOf(false) }
    Box(
        Modifier.fillMaxSize().clickable(enabled = enabled) { show = true },
        contentAlignment = Alignment.Center
    ) {
        if (value.isBlank()) {
            if (enabled) Text("Tap to sign", fontSize = 12.sp, color = Color(0xFF8A8F98))
        } else {
            val strokes = remember(value) { SignatureCodec.decode(value) }
            Canvas(Modifier.fillMaxSize().padding(2.dp)) { drawSignature(strokes, Ink, 3f) }
        }
    }
    if (show) {
        SignaturePadDialog(onDismiss = { show = false }, onSave = { onChange(it); show = false })
    }
}

@Composable
fun SignaturePadDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    val strokes = remember { mutableStateListOf<SnapshotStateList<Offset>>() }
    var size by remember { mutableStateOf(IntSize.Zero) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 6.dp,
            modifier = Modifier.fillMaxWidth(0.9f).widthIn(max = 720.dp)
        ) {
            Column(Modifier.padding(20.dp)) {
                Text("Sign in the box", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(10.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(SignatureCodec.ASPECT)
                        .background(Color.White, RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF9AA0A6), RoundedCornerShape(8.dp))
                        .onSizeChanged { size = it }
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { o -> strokes.add(mutableStateListOf(o)) },
                                onDrag = { change, _ -> strokes.lastOrNull()?.add(change.position) }
                            )
                        }
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        for (st in strokes) {
                            if (st.size < 2) continue
                            val p = Path()
                            st.forEachIndexed { i, pt -> if (i == 0) p.moveTo(pt.x, pt.y) else p.lineTo(pt.x, pt.y) }
                            drawPath(p, Ink, style = Stroke(width = 5f, cap = StrokeCap.Round, join = StrokeJoin.Round))
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End)) {
                    TextButton(onClick = { strokes.clear() }) { Text("Clear") }
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Button(onClick = {
                        onSave(SignatureCodec.encode(strokes.map { it.toList() }, size.width.toFloat(), size.height.toFloat()))
                    }) { Text("Save signature") }
                }
            }
        }
    }
}
