package com.gppol.tomsupervisorlog

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private suspend fun exportAsync(ctx: android.content.Context, data: ReportData): Result<ExportResult> =
    withContext(Dispatchers.IO) { runCatching { PdfExporter.export(ctx, data) } }

// ------------------------------------------------------------------ list

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListScreen(
    store: ReportStore,
    reports: List<Report>,
    onNew: () -> Unit,
    onOpen: (Report) -> Unit,
    onDeleted: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    var toDelete by remember { mutableStateOf<Report?>(null) }
    var exportResult by remember { mutableStateOf<ExportResult?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("TOM Supervisor's 2-Hourly Report", fontWeight = FontWeight.Bold)
                        Text("${FormMeta.DOC_NO}  ·  Rev ${FormMeta.REVISION}", fontSize = 12.sp)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onNew) { Text("+  New report", fontWeight = FontWeight.Bold) }
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            if (reports.isEmpty()) {
                Column(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No reports yet", style = MaterialTheme.typography.titleLarge)
                    Spacer(Modifier.height(8.dp))
                    Text("Tap “New report” to fill in the 2-hourly log sheet.", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    Modifier.widthIn(max = 900.dp).fillMaxSize(),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 12.dp, 16.dp, 96.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(reports, key = { it.id }) { r ->
                        ReportCard(
                            r,
                            onOpen = { onOpen(r) },
                            onExport = {
                                scope.launch {
                                    val res = exportAsync(ctx, r.snapshot())
                                    res.onSuccess { exportResult = it }
                                        .onFailure { snackbar.showSnackbar("PDF export failed: ${it.message}") }
                                }
                            },
                            onDelete = { toDelete = r }
                        )
                    }
                }
            }
        }
    }

    toDelete?.let { r ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("Delete this report?") },
            text = { Text("This removes the saved report from the app. PDFs already exported to the tablet are not deleted.") },
            confirmButton = {
                TextButton(onClick = { store.delete(r.id); toDelete = null; onDeleted() }) { Text("Delete", color = Color(0xFFB3261E)) }
            },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancel") } }
        )
    }
    exportResult?.let { ExportResultDialog(it) { exportResult = null } }
}

@Composable
private fun ReportCard(r: Report, onOpen: () -> Unit, onExport: () -> Unit, onDelete: () -> Unit) {
    val date = r.v("B6").ifBlank { null }?.let { formatDate(it) } ?: "No date"
    val time = listOf(r.v("F6"), r.v("F7")).filter { it.isNotBlank() }.joinToString(" – ")
    val submitted = r.status == Status.SUBMITTED
    Card(colors = CardDefaults.cardColors(containerColor = Color.White), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(date + if (time.isNotEmpty()) "   $time" else "", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(
                        "Supervisor: " + r.v("B75").ifBlank { "—" } + "     Updated " +
                            SimpleDateFormat("dd MMM HH:mm", Locale.ENGLISH).format(Date(r.updatedAt)),
                        fontSize = 13.sp, color = Color.Gray
                    )
                }
                Text(
                    if (submitted) "SUBMITTED" else "DRAFT",
                    color = if (submitted) Color(0xFF1B5E20) else Color(0xFF8A5A00),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    modifier = Modifier
                        .background(if (submitted) Color(0xFFD6F0DC) else Color(0xFFFFEFC7), RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onOpen) { Text(if (submitted) "View" else "Continue") }
                TextButton(onClick = onExport) { Text("Export PDF") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFB3261E)) }
            }
        }
    }
}

// ------------------------------------------------------------------ form

@OptIn(ExperimentalMaterial3Api::class, FlowPreview::class)
@Composable
fun FormScreen(report: Report, store: ReportStore, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val submitted = report.status == Status.SUBMITTED

    var showSubmit by remember { mutableStateOf(false) }
    var missing by remember { mutableStateOf<List<String>>(emptyList()) }
    var exportResult by remember { mutableStateOf<ExportResult?>(null) }
    var busy by remember { mutableStateOf(false) }

    // Autosave shortly after every edit so nothing is lost if the tablet sleeps or the app is closed.
    var dirty by remember { mutableStateOf(false) }
    LaunchedEffect(report) {
        snapshotFlow { report.values.toMap() }
            .drop(1)
            .onEach { dirty = true }
            .debounce(800)
            .collect {
                if (!report.isPristine()) store.save(report)
                dirty = false
            }
    }
    DisposableEffect(report) {
        onDispose { if (dirty && !report.isPristine()) store.save(report) }
    }

    fun close() {
        if (report.status == Status.DRAFT && report.isPristine()) store.delete(report.id)
        else if (dirty) store.save(report)
        onClose()
    }
    BackHandler { close() }

    fun exportNow() {
        val data = report.snapshot()
        busy = true
        scope.launch {
            val res = exportAsync(ctx, data)
            busy = false
            res.onSuccess { exportResult = it }
                .onFailure { snackbar.showSnackbar("PDF export failed: ${it.message}") }
        }
    }

    fun submit(export: Boolean) {
        report.status = Status.SUBMITTED
        report.submittedAt = System.currentTimeMillis()
        store.save(report)
        showSubmit = false
        if (export) exportNow() else scope.launch { snackbar.showSnackbar("Report submitted and saved") }
    }

    val title = report.v("B6").ifBlank { null }?.let { "Report · " + formatDate(it) } ?: "New report"

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, fontWeight = FontWeight.Bold)
                            Text(if (submitted) "Submitted – only the Verified By section can still be edited" else "Draft – saved automatically", fontSize = 12.sp)
                        }
                    },
                    navigationIcon = { TextButton(onClick = { close() }) { Text("‹ Back", color = Color.White, fontSize = 16.sp) } },
                    actions = { TextButton(onClick = { exportNow() }, enabled = !busy) { Text("Export PDF", color = Color.White, fontWeight = FontWeight.Bold) } },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        titleContentColor = Color.White
                    )
                )
                if (busy) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.End),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (!submitted) {
                        OutlinedButton(onClick = {
                            store.save(report)
                            scope.launch { snackbar.showSnackbar("Draft saved") }
                        }) { Text("Save draft") }
                        Button(onClick = {
                            val m = report.missingRequired()
                            if (m.isEmpty()) showSubmit = true else missing = m
                        }) { Text("Submit report") }
                    } else {
                        OutlinedButton(onClick = {
                            store.save(report)
                            scope.launch { snackbar.showSnackbar("Changes saved") }
                        }) { Text("Save changes") }
                        Button(onClick = { exportNow() }, enabled = !busy) { Text("Export PDF") }
                    }
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        SheetForm(report, locked = submitted, modifier = Modifier.padding(pad))
    }

    if (missing.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { missing = emptyList() },
            title = { Text("Complete these first") },
            text = { Text("Please fill in: " + missing.joinToString(", ") + ".") },
            confirmButton = { TextButton(onClick = { missing = emptyList() }) { Text("OK") } }
        )
    }

    if (showSubmit) {
        val blanks = report.blankReadings()
        AlertDialog(
            onDismissRequest = { showSubmit = false },
            title = { Text("Submit this report?") },
            text = {
                Column {
                    Text(
                        if (blanks > 0) "$blanks reading boxes are still blank. After submitting, the report is locked (the Verified By section can still be completed)."
                        else "All readings are filled in. After submitting, the report is locked (the Verified By section can still be completed)."
                    )
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { submit(true) }, modifier = Modifier.fillMaxWidth()) { Text("Save & export PDF") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { submit(false) }, modifier = Modifier.fillMaxWidth()) { Text("Save only") }
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = { showSubmit = false }, modifier = Modifier.fillMaxWidth()) { Text("Cancel – keep editing") }
                }
            },
            confirmButton = {}
        )
    }

    exportResult?.let { ExportResultDialog(it) { exportResult = null } }
}

@Composable
fun ExportResultDialog(result: ExportResult, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("PDF saved") },
        text = {
            Column {
                Text("Saved on this tablet in:")
                Text(result.displayPath, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))
                Text("Open the Files app and look in the Documents folder.", color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { PdfExporter.openPdf(ctx, result.uri) }, modifier = Modifier.fillMaxWidth()) { Text("Open PDF") }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { PdfExporter.sharePdf(ctx, result.uri) }, modifier = Modifier.fillMaxWidth()) { Text("Share…") }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } }
    )
}
