package com.gppol.tomsupervisorlog

// Derived from SHIFT_SUPERVISOR_2_HOURLY_REPORT.xlsx (NBPOL/PLS/12 Rev 1). Edit here if the sheet layout changes.
// Input keys are the Excel cell coordinates of the original log sheet (e.g. "C11" = Ramp 1, doors full),
// so every saved value can be traced back to the spreadsheet. Every row spans 10 columns (A..J).

enum class Kind { NUM, TEXT, YESNO, DATE, TIME, SIGN }

sealed class Cell(val span: Int) {
    class Label(val text: String, span: Int = 1) : Cell(span)
    class Input(val key: String, span: Int = 1, val kind: Kind = Kind.NUM, val underline: Boolean = false) : Cell(span)
    class Blank(span: Int = 1) : Cell(span)
}

class FormRow(val cells: List<Cell>, val tall: Boolean = false)

sealed class Block {
    class Section(val title: String) : Block()
    class Grid(val rows: List<FormRow>) : Block()
    /** Left 5 columns hold [rows]; right 5 columns hold one merged remarks box (like F60:J68 in the sheet). */
    class GridWithRemarks(val rows: List<FormRow>, val remarksKey: String, val remarksLabel: String) : Block()
    class Remarks(val key: String, val label: String, val rows: Int) : Block()
}

object FormMeta {
    const val DOC_NO = "NBPOL/PLS/12"
    const val REVISION = "1"
    const val REVISION_DATE = "04 Aug 2026"
    const val SITE = "TOM"
    const val TITLE = "TOM SUPERVISOR'S 2 HOURLY PROCESS REPORT LOG SHEET"

    /** Relative widths of sheet columns A..J (A and B are wider in the original). */
    val COLUMN_WEIGHTS = listOf(1.55f, 1.25f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f)

    /** Fields that stay editable after a report is submitted (verification step). */
    val VERIFICATION_KEYS = setOf("B77", "E77", "H77")

    /** Required before a report can be submitted. */
    val REQUIRED = listOf("B6" to "Date", "F6" to "Time Start", "F7" to "Time Stop", "B75" to "Shift Supervisor name", "E75" to "Shift Supervisor signature")
}

private fun L(text: String, span: Int = 1) = Cell.Label(text, span)
private fun I(key: String, span: Int = 1, kind: Kind = Kind.NUM, underline: Boolean = false) = Cell.Input(key, span, kind, underline)
private fun X(span: Int = 1) = Cell.Blank(span)
private fun row(vararg cells: Cell, tall: Boolean = false) = FormRow(cells.toList(), tall)

val FORM_BLOCKS: List<Block> = listOf(
    Block.Grid(listOf(
        row(L("DATE :"), I("B6", 2, Kind.DATE), X(), L("Time Start :"), I("F6", 2, Kind.TIME), X(3)),
        row(X(4), L("Time Stop :"), I("F7", 2, Kind.TIME), X(3))
    )),
    Block.Section("Reception"),
    Block.Grid(listOf(
        row(L("Ramp No.", 2), L("1"), L("2"), L("3"), L("4"), X(), L("EST.FFB Total on Ramp", 3)),
        row(L("No. of Doors Full", 2), I("C11"), I("D11"), I("E11"), I("F11"), X(), I("H11", 3))
    )),
    Block.Section("Sterilization"),
    Block.Grid(listOf(
        row(L("Sterilizer", 2), L("1"), L("2"), L("3"), L("4"), L("5"), L("6"), L("7"), X()),
        row(L("Cycles Processed", 2), I("C14"), I("D14"), I("E14"), I("F14"), I("G14"), I("H14"), I("I14"), X()),
        row(L("Pressure (Bar)", 2), I("C15"), I("D15"), I("E15"), I("F15"), I("G15"), I("H15"), I("I15"), X()),
        row(L("Peak", 2), I("C16"), I("D16"), I("E16"), I("F16"), I("G16"), I("H16"), I("I16"), X())
    )),
    Block.Section("Threshing"),
    Block.Grid(listOf(
        row(L("USB Spot Check (%)", 2), I("C18", 2), L("Do check for 100 samples", 3), X(3)),
        row(X(5), L("EST.FFB Processed", 2), I("H19", 2), X()),
        row(L("Thresher", 2), L("1"), L("2"), X(), L("Total Milling Hours", 2), I("H20", 2), X()),
        row(L("Cages Tipped", 2), I("C21"), I("D21"), X(), L("Mill TPH", 2), I("H21", 2), X()),
        row(L("Total Cages Tipped", 2), I("C22", 2), X(6))
    )),
    Block.Section("Power Generation"),
    Block.Grid(listOf(
        row(L("BPR (Bar)"), L("TA1 (kW)"), L("TA2 (kW)"), L("DA1 (kW)"), L("DA2 (kW)"), L("DA3 (kW)"), X(4)),
        row(I("A25"), I("B25"), I("C25"), I("D25"), I("E25"), I("F25"), X(4))
    )),
    Block.Section("Press & Digester"),
    Block.Grid(listOf(
        row(L("Press"), L("1"), L("2"), L("3"), L("4"), X(), L("Hot Water Tank Temp (deg. C)", 3), I("J27")),
        row(L("AMPS"), I("B28"), I("C28"), I("D28"), I("E28"), X(), L("Condensate Tank Temp (deg.C)", 3), I("J28")),
        row(L("Digester"), L("1"), L("2"), L("3"), L("4"), X(), L("Dilution Box Temp (deg. C)", 3), I("J29")),
        row(L("AMPS"), I("B30"), I("C30"), I("D30"), I("E30"), X(5)),
        row(L("Temperature"), I("B31"), I("C31"), I("D31"), I("E31"), X(5)),
        row(L("Level"), I("B32"), I("C32"), I("D32"), I("E32"), X(5))
    )),
    Block.Section("Clarification"),
    Block.Grid(listOf(
        row(L("VCT"), L("1"), L("2"), X(), L("Vacuum Dryer (bar)", 2), I("G34", 2), X(2)),
        row(L("Oil Layer (ft)"), I("B35"), I("C35"), X(), L("Sludge Tank Level", 2), I("G35", 2), X(2)),
        row(L("POT"), L("1"), L("2"), X(), L("Centrifuge"), L("1"), L("2"), L("3"), L("4"), X()),
        row(L("Oil Layer (ft)"), I("B37"), I("C37"), X(), L("In operation"), I("F37", 1, Kind.YESNO), I("G37", 1, Kind.YESNO), I("H37", 1, Kind.YESNO), I("I37", 1, Kind.YESNO), X())
    )),
    Block.Section("Kernel Recovery"),
    Block.Grid(listOf(
        row(L("Nut Silo"), L("1"), L("2"), X(3), L("K-Silo"), L("1"), L("2"), L("3")),
        row(L("Level"), I("B40"), I("C40"), X(3), L("Moisture (%)"), I("H40"), I("I40"), I("J40")),
        row(L("Kernel Silo", 2), L("1"), L("2"), L("3"), X(5)),
        row(L("Level", 2), I("C42"), I("D42"), I("E42"), X(5)),
        row(L("Temp (deg.C)", 2), I("C43"), I("D43"), I("E43"), X(5))
    )),
    Block.Section("Boiler"),
    Block.Grid(listOf(
        row(L("Boiler", 2), L("1", 2), L("2", 2), X(), L("Dosing pump"), L("1"), L("2")),
        row(L("Pressure (bar)", 2), I("C46", 2), I("E46", 2), X(), L("In Operation"), I("I46", 1, Kind.YESNO), I("J46", 1, Kind.YESNO)),
        row(L("Steam Flow (T/hr)", 2), I("C47", 2), I("E47", 2), X(4)),
        row(L("Lowest Pressure (bar)", 2), I("C48", 2), I("E48", 2), X(4)),
        row(L("Tank"), L("Feed Water"), L("RO"), L("RAW"), X(6)),
        row(L("Level"), I("B50"), I("C50"), I("D50"), X(6)),
        row(L("Temp"), I("B51"), I("C51"), I("D51"), X(6))
    )),
    Block.Section("KCP"),
    Block.Grid(listOf(
        row(L("P-Press"), L("1"), L("2"), L("3"), L("4"), X(5)),
        row(L("Hopper Level"), I("B54"), I("C54"), I("D54"), I("E54"), X(5)),
        row(L("Amps"), I("B55"), I("C55"), I("D55"), I("E55"), X(5)),
        row(L("S-Press"), L("1"), L("2"), L("3"), L("4"), X(5)),
        row(L("Hopper Level"), I("B57"), I("C57"), I("D57"), I("E57"), X(5)),
        row(L("Amps"), I("B58"), I("C58"), I("D58"), I("E58"), X(5))
    )),
    Block.Section("Quality Check"),
    Block.GridWithRemarks(listOf(
        row(L("COT Spot Check"), L("OIL"), L("Water"), L("NOS"), L("3rd Layer")),
        row(L("Composition %"), I("B61"), I("C61"), I("D61"), I("E61")),
        row(L("UF1 Spot Check"), L("OIL"), L("Water"), L("NOS"), L("3rd Layer")),
        row(L("Composition %"), I("B63"), I("C63"), I("D63"), I("E63")),
        row(L("UF2 Spot Check"), L("OIL"), L("Water"), L("NOS"), L("3rd Layer")),
        row(L("Composition %"), I("B65"), I("C65"), I("D65"), I("E65")),
        row(X(5)),
        row(L("FFA Spot check"), L("Str Cond"), L("Press"), L("PO"), X()),
        row(L("%"), I("B68"), I("C68"), I("D68"), X())
    ), "F60", "Remarks about Quality Check:"),
    Block.Section("Remarks & Verification"),
    Block.Remarks("A70", "Remarks:", 4),
    Block.Grid(listOf(
        row(L("Shift Supervisor :"), I("B75", 2, Kind.TEXT, true), L("Signature :"), I("E75", 2, Kind.SIGN, true), X(4), tall = true),
        row(L("Verified By :"), I("B77", 2, Kind.TEXT, true), L("Signature :"), I("E77", 2, Kind.SIGN, true), L("Date :"), I("H77", 2, Kind.DATE, true), X(), tall = true)
    ))
)

/** All keys that hold data, used for counting blank readings. */
val READING_KEYS: List<String> = FORM_BLOCKS.flatMap { b ->
    val rows = when (b) { is Block.Grid -> b.rows; is Block.GridWithRemarks -> b.rows; else -> emptyList() }
    rows.flatMap { r -> r.cells.filterIsInstance<Cell.Input>().filter { it.kind == Kind.NUM || it.kind == Kind.YESNO }.map { it.key } }
}
