package com.gppol.tomsupervisorlog

import android.content.ActivityNotFoundException
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ExportResult(val uri: Uri, val displayPath: String)

/**
 * Draws the log sheet onto a single A4 portrait page (same layout as the Excel sheet: 10 columns A..J)
 * and saves it to Documents/TOM_Reports so it shows up in the tablet's file manager.
 */
object PdfExporter {
    private const val PAGE_W = 595
    private const val PAGE_H = 842
    private const val MARGIN = 20f
    private const val FOLDER = "TOM_Reports"

    fun fileName(d: ReportData): String {
        val date = d.values["B6"]?.takeIf { it.isNotBlank() } ?: "undated"
        val start = d.values["F6"].orEmpty().replace(":", "")
        val stop = d.values["F7"].orEmpty().replace(":", "")
        val time = when {
            start.isNotEmpty() && stop.isNotEmpty() -> "_$start-$stop"
            start.isNotEmpty() -> "_$start"
            else -> ""
        }
        return "TOM_2Hourly_Report_$date$time.pdf"
    }

    private fun pageInfo(n: Int) = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, n).create()

    fun build(d: ReportData): PdfDocument {
        val doc = PdfDocument()
        val page = doc.startPage(pageInfo(1))
        val renderer = SheetRenderer(page.canvas, d)
        renderer.draw()
        doc.finishPage(page)
        if (renderer.overflow.isNotEmpty()) drawContinuation(doc, d, renderer.overflow)
        return doc
    }

    /** Remarks too long for their box on the sheet are printed in full on extra pages. */
    private fun drawContinuation(doc: PdfDocument, d: ReportData, items: List<Pair<String, String>>) {
        val head = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; textSize = 11f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val label = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK; textSize = 9f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B2E7A"); textSize = 9f }
        val maxW = PAGE_W - 2 * MARGIN
        val lineH = 12f
        val title = "${FormMeta.DOC_NO} - Remarks (continued) - " + formatDate(d.values["B6"].orEmpty()) +
            d.values["F6"]?.takeIf { it.isNotBlank() }?.let { "  $it" }.orEmpty() +
            d.values["F7"]?.takeIf { it.isNotBlank() }?.let { " - $it" }.orEmpty()

        var pageNo = 2
        var page = doc.startPage(pageInfo(pageNo))
        var y = 0f
        fun startPage() {
            page.canvas.drawText(title, MARGIN, MARGIN + 12f, head)
            y = MARGIN + 36f
        }
        startPage()
        for ((lbl, text) in items) {
            page.canvas.drawText(lbl, MARGIN, y, label)
            y += lineH
            for (ln in wrapText(text, body, maxW)) {
                if (y > PAGE_H - MARGIN) {
                    doc.finishPage(page)
                    pageNo++
                    page = doc.startPage(pageInfo(pageNo))
                    startPage()
                }
                page.canvas.drawText(ln, MARGIN, y, body)
                y += lineH
            }
            y += lineH
        }
        doc.finishPage(page)
    }

    /** Blocking; call from a background thread. */
    fun export(ctx: Context, d: ReportData): ExportResult {
        val name = fileName(d)
        val doc = build(d)
        try {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) saveToDocuments(ctx, name, doc)
            else saveLegacy(ctx, name, doc)
        } finally {
            doc.close()
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun saveToDocuments(ctx: Context, name: String, doc: PdfDocument): ExportResult {
        val resolver = ctx.contentResolver
        val collection = MediaStore.Files.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val rel = Environment.DIRECTORY_DOCUMENTS + "/" + FOLDER + "/"

        fun write(uri: Uri): Boolean = runCatching {
            resolver.openOutputStream(uri, "wt")?.use { doc.writeTo(it) } != null
        }.getOrDefault(false)

        // Re-exporting the same report overwrites its earlier PDF instead of creating "(1)" copies.
        var existing: Uri? = null
        resolver.query(
            collection,
            arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?",
            arrayOf(name, rel),
            null
        )?.use { c -> if (c.moveToFirst()) existing = ContentUris.withAppendedId(collection, c.getLong(0)) }

        val reuse = existing
        if (reuse != null && write(reuse)) return ExportResult(reuse, "Documents/$FOLDER/$name")

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
        }
        val created = resolver.insert(collection, values) ?: throw IOException("Could not create a file in Documents")
        if (!write(created)) throw IOException("Could not write the PDF")
        return ExportResult(created, "Documents/$FOLDER/$name")
    }

    private fun saveLegacy(ctx: Context, name: String, doc: PdfDocument): ExportResult {
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), FOLDER)
        dir.mkdirs()
        val file = File(dir, name)
        FileOutputStream(file).use { doc.writeTo(it) }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file)
        return ExportResult(uri, "Android/data/${ctx.packageName}/files/Documents/$FOLDER/$name")
    }

    fun openPdf(ctx: Context, uri: Uri) {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            ctx.startActivity(i)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(ctx, "No PDF viewer installed. Open the file from the Files app instead.", Toast.LENGTH_LONG).show()
        }
    }

    fun sharePdf(ctx: Context, uri: Uri) {
        val i = Intent(Intent.ACTION_SEND).setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(i, "Share report"))
    }
}

private fun wrapText(text: String, p: Paint, maxW: Float): List<String> {
    val out = mutableListOf<String>()
    for (para in text.split("\n")) {
        if (para.isEmpty()) { out.add(""); continue }
        var cur = ""
        for (word in para.split(" ")) {
            val cand = if (cur.isEmpty()) word else "$cur $word"
            if (p.measureText(cand) <= maxW) {
                cur = cand
            } else {
                if (cur.isNotEmpty()) { out.add(cur); cur = "" }
                var w = word
                while (p.measureText(w) > maxW && w.length > 1) {
                    val n = p.breakText(w, true, maxW, null).coerceAtLeast(1)
                    out.add(w.substring(0, n))
                    w = w.substring(n)
                }
                cur = w
            }
        }
        out.add(cur)
    }
    return out
}

private class SheetRenderer(private val c: Canvas, private val d: ReportData) {
    private val left = 20f
    private val width = 595f - 40f
    private val weights = FormMeta.COLUMN_WEIGHTS
    private val colX = FloatArray(11).also {
        var acc = 0f
        for (i in 0..10) {
            it[i] = left + width * acc / weights.sum()
            if (i < 10) acc += weights[i]
        }
    }

    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 0.6f; color = Color.BLACK }
    private val headFill = Paint().apply { style = Paint.Style.FILL; color = Color.parseColor("#D9D9D9") }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#111111"); textSize = 6.8f }
    private val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; textSize = 7.4f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0B2E7A"); textSize = 7.6f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val notePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0B2E7A"); textSize = 7.2f }
    private val sigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 0.9f; color = Color.parseColor("#0B2E7A")
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val footPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.GRAY; textSize = 5.5f }

    val overflow = mutableListOf<Pair<String, String>>()

    private val headerUnits = 4f
    private val gapUnits = 0.6f
    private val sectionUnits = 1.15f
    private val tallUnits = 2.4f
    private val footerH = 14f

    private fun rowUnits(r: FormRow) = if (r.tall) tallUnits else 1f

    fun draw() {
        var units = headerUnits + gapUnits
        for (b in FORM_BLOCKS) {
            units += when (b) {
                is Block.Section -> sectionUnits
                is Block.Grid -> b.rows.fold(0f) { a, r -> a + rowUnits(r) }
                is Block.GridWithRemarks -> b.rows.size.toFloat()
                is Block.Remarks -> b.rows.toFloat()
            }
        }
        val unit = ((842f - 2 * 20f - footerH) / units).coerceAtMost(14f)
        var y = 20f

        drawHeader(y, unit)
        y += (headerUnits + gapUnits) * unit

        for (b in FORM_BLOCKS) {
            when (b) {
                is Block.Section -> {
                    val r = RectF(colX[0], y, colX[10], y + sectionUnits * unit)
                    c.drawRect(r, headFill); c.drawRect(r, line)
                    drawFit(b.title, r, boldPaint, Paint.Align.CENTER)
                    y += sectionUnits * unit
                }
                is Block.Grid -> for (row in b.rows) {
                    val h = rowUnits(row) * unit
                    drawRow(row, y, h)
                    y += h
                }
                is Block.GridWithRemarks -> {
                    val top = y
                    for (row in b.rows) { drawRow(row, y, unit); y += unit }
                    val r = RectF(colX[5], top, colX[10], y)
                    c.drawRect(r, line)
                    drawNote(b.remarksLabel, d.values[b.remarksKey].orEmpty(), r)
                }
                is Block.Remarks -> {
                    val r = RectF(colX[0], y, colX[10], y + b.rows * unit)
                    c.drawRect(r, line)
                    drawNote(b.label, d.values[b.key].orEmpty(), r)
                    y += b.rows * unit
                }
            }
        }
        drawFooter()
    }

    private fun drawHeader(y: Float, unit: Float) {
        val info = listOf(
            "Document No." to FormMeta.DOC_NO,
            "Revision" to FormMeta.REVISION,
            "Revision Date" to FormMeta.REVISION_DATE,
            "Mill/Site" to FormMeta.SITE
        )
        info.forEachIndexed { i, (k, v) ->
            val top = y + i * unit
            val a = RectF(colX[0], top, colX[1], top + unit)
            val b = RectF(colX[1], top, colX[3], top + unit)
            c.drawRect(a, line); c.drawRect(b, line)
            drawFit(k, a, labelPaint, Paint.Align.LEFT)
            drawFit(v, b, boldPaint, Paint.Align.LEFT)
        }
        val title = RectF(colX[3], y, colX[7], y + headerUnits * unit)
        c.drawRect(title, line)
        val bigBold = Paint(boldPaint).apply { textSize = 9.5f }
        val parts = listOf("TOM SUPERVISOR'S 2 HOURLY", "PROCESS REPORT LOG SHEET")
        parts.forEachIndexed { i, s ->
            val r = RectF(title.left, title.top + i * title.height() / 2, title.right, title.top + (i + 1) * title.height() / 2)
            drawFit(s, r, bigBold, Paint.Align.CENTER)
        }
        val right = RectF(colX[7], y, colX[10], y + headerUnits * unit)
        c.drawRect(right, line)
        drawFit("Page 1", right, labelPaint, Paint.Align.CENTER)
    }

    private fun drawRow(row: FormRow, y: Float, h: Float) {
        var col = 0
        for (cell in row.cells) {
            val r = RectF(colX[col], y, colX[col + cell.span], y + h)
            when (cell) {
                is Cell.Blank -> {}
                is Cell.Label -> {
                    if (!row.tall) c.drawRect(r, line)
                    val centred = labelCentered(cell.text, cell.span, col)
                    val p = if (cell.text.all { it.isDigit() }) boldPaint else labelPaint
                    drawFit(cell.text, r, p, if (centred) Paint.Align.CENTER else Paint.Align.LEFT)
                }
                is Cell.Input -> drawInput(cell, r)
            }
            col += cell.span
        }
    }

    private fun drawInput(cell: Cell.Input, r: RectF) {
        if (cell.underline) c.drawLine(r.left, r.bottom, r.right, r.bottom, line) else c.drawRect(r, line)
        val v = d.values[cell.key].orEmpty()
        if (v.isBlank()) return
        when (cell.kind) {
            Kind.SIGN -> drawSignature(v, r)
            Kind.DATE -> drawFit(formatDate(v), r, valuePaint, Paint.Align.CENTER)
            Kind.TEXT -> drawFit(v, r, valuePaint, Paint.Align.LEFT)
            else -> drawFit(v, r, valuePaint, Paint.Align.CENTER)
        }
    }

    private fun drawSignature(encoded: String, r: RectF) {
        val strokes = SignatureCodec.decode(encoded)
        val inner = RectF(r.left + 2f, r.top + 1.5f, r.right - 2f, r.bottom - 1.5f)
        val s = minOf(inner.width() / SignatureCodec.ASPECT, inner.height())
        val ox = inner.left + (inner.width() - s * SignatureCodec.ASPECT) / 2f
        val oy = inner.top + (inner.height() - s) / 2f
        for (st in strokes) {
            if (st.size == 1) {
                c.drawPoint(ox + st[0].x * s * SignatureCodec.ASPECT, oy + st[0].y * s, sigPaint)
            } else {
                val p = Path()
                st.forEachIndexed { i, pt ->
                    val x = ox + pt.x * s * SignatureCodec.ASPECT
                    val y = oy + pt.y * s
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                c.drawPath(p, sigPaint)
            }
        }
    }

    /** Draws [text] on one line, shrinking the font (down to a floor) so it fits the box. */
    private fun drawFit(text: String, r: RectF, base: Paint, align: Paint.Align) {
        if (text.isEmpty()) return
        val p = Paint(base)
        val maxW = r.width() - 4f
        while (p.measureText(text) > maxW && p.textSize > 4.4f) p.textSize -= 0.2f
        p.textAlign = align
        val fm = p.fontMetrics
        val baseline = r.centerY() - (fm.ascent + fm.descent) / 2f
        val x = if (align == Paint.Align.CENTER) r.centerX() else r.left + 2.5f
        c.drawText(text, x, baseline, p)
    }

    /** Remarks box: bold caption in the corner, free text wrapped below it. */
    private fun drawNote(label: String, body: String, r: RectF) {
        val pad = 2.5f
        val lp = Paint(labelPaint).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val labelBaseline = r.top + pad - lp.fontMetrics.ascent
        c.drawText(label, r.left + pad, labelBaseline, lp)
        if (body.isBlank()) return

        val availH = r.bottom - (labelBaseline + 2f) - pad
        val maxW = r.width() - 2 * pad
        val p = Paint(notePaint)
        var lines = wrapText(body, p, maxW)
        while (lines.size * p.textSize * 1.2f > availH && p.textSize > 4.6f) {
            p.textSize -= 0.2f
            lines = wrapText(body, p, maxW)
        }
        val lineH = p.textSize * 1.2f
        val fit = (availH / lineH).toInt().coerceAtLeast(1)
        if (lines.size > fit) {
            overflow.add(label to body)
            val suffix = " [cont. p2]"
            var last = lines[fit - 1]
            while (last.isNotEmpty() && p.measureText(last + suffix) > maxW) last = last.dropLast(1)
            lines = lines.take(fit - 1) + (last.trimEnd() + suffix)
        }
        var y = labelBaseline + 2f - p.fontMetrics.ascent
        for (ln in lines) {
            c.drawText(ln, r.left + pad, y, p)
            y += lineH
        }
    }

    private fun drawFooter() {
        val fmt = SimpleDateFormat("dd MMM yyyy HH:mm", Locale.ENGLISH)
        val status = if (d.status == Status.SUBMITTED) {
            "SUBMITTED" + (d.submittedAt?.let { " " + fmt.format(Date(it)) } ?: "")
        } else "DRAFT (not yet submitted)"
        val text = "${FormMeta.DOC_NO}  Rev ${FormMeta.REVISION}  |  $status  |  PDF generated ${fmt.format(Date())} by TOM Supervisor Log app"
        c.drawText(text, 20f, 842f - 12f, footPaint)
    }
}
