package com.gppol.tomsupervisorlog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TomLogTheme { App() } }
    }
}

private val Colors = lightColorScheme(
    primary = Color(0xFF2F5D50),
    onPrimary = Color.White,
    secondary = Color(0xFF8A5A00),
    background = Color(0xFFF7F8FA),
    surface = Color.White,
    surfaceVariant = Color(0xFFE7ECEA)
)

@Composable
fun TomLogTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val store = remember { ReportStore(ctx.applicationContext) }
    var reports by remember { mutableStateOf(store.loadAll()) }
    var current by remember { mutableStateOf<Report?>(null) }

    val open = current
    if (open == null) {
        ListScreen(
            store = store,
            reports = reports,
            onNew = { current = store.create() },
            onOpen = { current = it },
            onDeleted = { reports = store.loadAll() }
        )
    } else {
        FormScreen(
            report = open,
            store = store,
            onClose = {
                current = null
                reports = store.loadAll()
            }
        )
    }
}
